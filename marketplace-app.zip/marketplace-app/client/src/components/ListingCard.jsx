import { Link } from 'react-router-dom';

const TypeTag = ({ type }) => {
  if (type === 'sale') {
    return (
      <span className="text-xs font-mono uppercase tracking-wide px-2 py-1 rounded-full bg-clay/10 text-clay border border-clay/30">
        For sale
      </span>
    );
  }
  if (type === 'rent') {
    return (
      <span className="text-xs font-mono uppercase tracking-wide px-2 py-1 rounded-full bg-sage-100 text-sage-700 border border-sage-400/40">
        For rent
      </span>
    );
  }
  return (
    <div className="flex gap-1.5">
      <span className="text-xs font-mono uppercase tracking-wide px-2 py-1 rounded-full bg-clay/10 text-clay border border-clay/30">
        Sale
      </span>
      <span className="text-xs font-mono uppercase tracking-wide px-2 py-1 rounded-full bg-sage-100 text-sage-700 border border-sage-400/40">
        Rent
      </span>
    </div>
  );
};

const ListingCard = ({ listing }) => {
  const image = listing.images?.[0] || 'https://placehold.co/600x400/EEF2EE/3B5641?text=No+Image';

  return (
    <Link
      to={`/listings/${listing._id}`}
      className="group block rounded-2xl border border-sage-100 bg-white overflow-hidden hover:shadow-md hover:-translate-y-0.5 transition-all"
    >
      <div className="aspect-[4/3] overflow-hidden bg-sage-50">
        <img
          src={image}
          alt={listing.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
      </div>
      <div className="p-4 space-y-2">
        <TypeTag type={listing.listingType} />
        <h3 className="font-display text-lg font-semibold text-ink leading-snug">
          {listing.title}
        </h3>
        <p className="text-sm text-ink/60">{listing.location}</p>
        <div className="flex items-baseline gap-3 font-mono text-sm">
          {(listing.listingType === 'sale' || listing.listingType === 'both') && listing.salePrice && (
            <span className="text-ink font-semibold">${listing.salePrice}</span>
          )}
          {(listing.listingType === 'rent' || listing.listingType === 'both') && listing.rentalRate && (
            <span className="text-sage-700">
              ${listing.rentalRate}/{listing.rentalUnit}
            </span>
          )}
        </div>
        {listing.status === 'sold' && (
          <span className="text-xs font-mono uppercase text-ink/40">Sold</span>
        )}
      </div>
    </Link>
  );
};

export default ListingCard;
