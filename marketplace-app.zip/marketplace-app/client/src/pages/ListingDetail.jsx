import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import api from '../api/axios.js';
import { useAuth } from '../context/AuthContext.jsx';
import BookingRequestForm from '../components/BookingRequestForm.jsx';

const ListingDetail = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const [listing, setListing] = useState(null);
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(true);

  const fetchListing = async () => {
    try {
      const { data } = await api.get(`/listings/${id}`);
      setListing(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchListing();
  }, [id]);

  const handleBuy = async () => {
    try {
      await api.post(`/listings/${id}/buy`);
      setMessage('Purchase confirmed! The owner will be in touch to arrange handoff.');
      fetchListing();
    } catch (err) {
      setMessage(err.response?.data?.message || 'Could not complete purchase');
    }
  };

  if (loading) return <p className="max-w-4xl mx-auto px-6 py-12 text-ink/50">Loading...</p>;
  if (!listing) return <p className="max-w-4xl mx-auto px-6 py-12 text-ink/50">Listing not found.</p>;

  const isOwner = user && listing.owner._id === user._id;
  const image = listing.images?.[0] || 'https://placehold.co/800x600/EEF2EE/3B5641?text=No+Image';

  return (
    <div className="max-w-4xl mx-auto px-6 py-12">
      <div className="grid md:grid-cols-2 gap-10">
        <div className="rounded-2xl overflow-hidden bg-sage-50 aspect-[4/3]">
          <img src={image} alt={listing.title} className="w-full h-full object-cover" />
        </div>

        <div>
          <h1 className="font-display text-3xl font-semibold text-ink mb-2">{listing.title}</h1>
          <p className="text-ink/60 mb-4">{listing.location} · {listing.category}</p>

          <div className="flex gap-4 font-mono mb-6">
            {(listing.listingType === 'sale' || listing.listingType === 'both') && listing.salePrice && (
              <div className="px-4 py-2 rounded-xl bg-clay/10 border border-clay/30">
                <p className="text-xs uppercase text-clay/80">Buy</p>
                <p className="text-lg font-semibold text-clay">${listing.salePrice}</p>
              </div>
            )}
            {(listing.listingType === 'rent' || listing.listingType === 'both') && listing.rentalRate && (
              <div className="px-4 py-2 rounded-xl bg-sage-100 border border-sage-400/40">
                <p className="text-xs uppercase text-sage-700/80">Borrow</p>
                <p className="text-lg font-semibold text-sage-700">
                  ${listing.rentalRate}/{listing.rentalUnit}
                </p>
              </div>
            )}
          </div>

          <p className="text-ink/80 leading-relaxed mb-6">{listing.description}</p>

          <p className="text-sm text-ink/50 mb-6">Listed by {listing.owner?.name}</p>

          {listing.status === 'sold' ? (
            <p className="text-clay font-medium">This item has been sold.</p>
          ) : isOwner ? (
            <p className="text-sm text-ink/50 italic">This is your listing.</p>
          ) : !user ? (
            <p className="text-sm text-ink/60">
              <a href="/login" className="text-sage-600 font-medium">Log in</a> to buy or borrow this item.
            </p>
          ) : (
            <div className="space-y-4">
              {(listing.listingType === 'sale' || listing.listingType === 'both') && (
                <button
                  onClick={handleBuy}
                  className="w-full py-2.5 rounded-full bg-clay text-paper font-medium hover:bg-clay/90 transition-colors"
                >
                  Buy now — ${listing.salePrice}
                </button>
              )}
              {(listing.listingType === 'rent' || listing.listingType === 'both') && (
                <BookingRequestForm
                  listing={listing}
                  onSuccess={() => setMessage('Borrow request sent! Check your dashboard for status.')}
                />
              )}
              {message && <p className="text-sm text-sage-700">{message}</p>}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ListingDetail;
