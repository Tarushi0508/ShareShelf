import { useEffect, useState } from 'react';
import api from '../api/axios.js';
import ListingCard from '../components/ListingCard.jsx';

const Home = () => {
  const [listings, setListings] = useState([]);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');
  const [loading, setLoading] = useState(true);

  const fetchListings = async () => {
    setLoading(true);
    try {
      const params = {};
      if (search) params.search = search;
      if (filter !== 'all') params.listingType = filter;
      const { data } = await api.get('/listings', { params });
      setListings(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchListings();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filter]);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    fetchListings();
  };

  return (
    <div className="max-w-6xl mx-auto px-6 py-10">
      <div className="mb-10">
        <h1 className="font-display text-4xl font-semibold text-ink mb-2">
          Buy it outright, or borrow it for a while.
        </h1>
        <p className="text-ink/60 max-w-xl">
          Every listing here can be bought or rented — your choice. List what you're not
          using, find what you only need for now.
        </p>
      </div>

      <form onSubmit={handleSearchSubmit} className="flex flex-wrap gap-3 mb-8">
        <input
          type="text"
          placeholder="Search listings..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="flex-1 min-w-[200px] px-4 py-2.5 rounded-full border border-sage-100 bg-white text-sm"
        />
        <div className="flex gap-2">
          {['all', 'sale', 'rent', 'both'].map((type) => (
            <button
              key={type}
              type="button"
              onClick={() => setFilter(type)}
              className={`px-4 py-2.5 rounded-full text-sm font-medium border transition-colors capitalize ${
                filter === type
                  ? 'bg-ink text-paper border-ink'
                  : 'bg-white text-ink/70 border-sage-100 hover:border-ink/30'
              }`}
            >
              {type}
            </button>
          ))}
        </div>
      </form>

      {loading ? (
        <p className="text-ink/50">Loading listings...</p>
      ) : listings.length === 0 ? (
        <p className="text-ink/50">No listings yet. Be the first to list something.</p>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {listings.map((listing) => (
            <ListingCard key={listing._id} listing={listing} />
          ))}
        </div>
      )}
    </div>
  );
};

export default Home;
